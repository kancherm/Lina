package com.example.meghanakancherla.myapplication;

public interface NetworkStateChangeListener {
    void onNetworkStateChanged(int networkState);
}
